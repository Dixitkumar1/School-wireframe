# trip_planner.py

# Input for rain and friend's availability
rain = input("Will it rain? (True/False): ") == 'True'
friend_available = input("Is your friend available? (True/False): ") == 'True'

# Check both conditions
if not rain and friend_available:
    print("You can proceed with the trip")
else:
    print("You cannot proceed with the trip")
