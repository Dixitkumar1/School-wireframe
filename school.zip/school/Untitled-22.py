x = int(input("Enter a number: "))
if x > 0:
    for i in range(1, x + 1):
        print(i, end=" ")
elif x < 0:
    for i in range(x, 1):
        print(abs(i), end=" ")
else:
    print("Zero is neither positive nor negative")
