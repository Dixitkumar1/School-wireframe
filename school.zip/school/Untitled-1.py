total_budget = int(input("Enter the total budget: "))
venue_rent = int(input("Enter the venue rent: "))
guest_speakers = int(input("Enter the guest speakers' fee: "))
marketing = int(input("Enter the marketing budget: "))
remaining_budget = total_budget - (venue_rent + guest_speakers + marketing)
print(f"The remaining budget is {remaining_budget}")

