# Input for rain and friend's availability
rain = input() == 'True'
friend_available = input() == 'True'

# Check both conditions
if not rain and friend_available:
    print("You can proceed with the trip")
else:
    print("You cannot proceed with the trip")
